<?php
/**
 *
 * Events Calendar An extension for the phpBB 3.2.0 Forum Software package.
 * @author Steve <http://www.steven-clark.online/phpBB3-Extensions/>
 * @copyright (c) phpBB Limited <https://www.phpbb.com>
 * @license GNU General Public License, version 2 (GPL-2.0)
 * 30%
 */

namespace steve\calendar\controller;

use steve\calendar\calendar\constants;

/**
 * controller.
 */
 
class actions
{
	/** @var \phpbb\auth\auth */
	protected $auth;

	/** @var \phpbb\config\config */
	protected $config;

	/** @var \phpbb\db\driver\driver */
	protected $db;

	/** @var \phpbb\controller\helper */
	protected $helper;

	/** @var \phpbb\language\language */
	protected $language;
	
	/** @var \phpbb\notification\manager */
	protected $notification_manager;
		
	/** @var \phpbb\request\request */
	protected $request;
	
	/** @var \phpbb\template\template */
	protected $template;
	
	/** @var \phpbb\user */
	protected $user;

	protected $posting;
	protected $date;
	protected $calendar_events;
	protected $calendar_events_attending;
	
	/**
	 * Constructor
	 */
	public function __construct(
		\phpbb\auth\auth $auth,
		\phpbb\config\config $config,
		\phpbb\db\driver\driver_interface $db,		
		\phpbb\controller\helper $helper,
		\phpbb\language\language $language,
		\phpbb\notification\manager $notification_manager,	
		\phpbb\request\request $request,
		\phpbb\template\template $template,
		\phpbb\user $user,
		//
		\steve\calendar\calendar\event_posting $posting,
		\steve\calendar\calendar\date_time $date,
		$calendar_events,
		$calendar_events_attending)
	{
		$this->auth = $auth;
		$this->config = $config;		
		$this->db = $db;	
		$this->helper = $helper;
		$this->language = $language;
		$this->notification_manager = $notification_manager;
		$this->request = $request;
		$this->template = $template;
		$this->user = $user;
		//
		$this->posting = $posting;
		$this->date_time = $date;
		$this->table_calendar_events = $calendar_events;
		$this->table_events_attending = $calendar_events_attending;
		
		$this->language->add_lang('calendar', 'steve/calendar');
	}
	//confirm
	public function delete_event($event_id)
	{
		if (!check_link_hash($this->request->variable('hash', ''), 'delete'))
		{
			throw new \phpbb\exception\http_exception(403, 'NO_AUTH_OPERATION');
		}
		
		$event_data = $this->posting->get_event($event_id);
		if (empty($event_id) || empty($event_data))
		{
			throw new \phpbb\exception\http_exception(404, 'EVENT_EMPTY');
		}
		
		if (!$this->posting->u_event_action('u_delete_calendar_event', $event_data['user_id']))
		{
			throw new \phpbb\exception\http_exception(403, 'NO_AUTH_DELETE_EVENT');
		}
			
		if ($this->request->is_ajax())
		{
			$sql = 'DELETE FROM ' . $this->table_events_attending . '
				WHERE event_id = ' . (int) $event_id;
			$this->db->sql_query($sql);
			
			$sql = 'DELETE FROM ' . $this->table_calendar_events . '
				WHERE event_id = ' . (int) $event_id;
			$this->db->sql_query($sql);

			$this->notification_manager->delete_notifications('steve.calendar.notification.type.upcoming_event', [
				'item_id'			=> $event_id,
				//'item_partent_id'	=> $event_id,
			]);
			
			$data = [
				'EVENT_ID'	=> $event_id,
				'MESSAGE_TITLE'	=> $this->language->lang('INFORMATION'),
				'MESSAGE_TEXT'	=> $this->language->lang('EVENT_DELETED'),
			];
			
			$json_response = new \phpbb\json_response;
			return $json_response->send($data);
		}

		return $this;
	}
	
	public function event_actions($action, $event_id)
	{
                
                      
		if (empty($action) || !in_array($action, array('add', 'edit')) || ($action == 'add' && !empty($event_id)) || ($action == 'edit' && empty($event_id)))
		{
			throw new \phpbb\exception\http_exception(403, 'INVALID_EVENT_ACTION');
		}
		
 		if ($action == 'add' && !$this->auth->acl_get('u_add_calendar_event'))
		{
			throw new \phpbb\exception\http_exception(403, 'NO_AUTH_OPERATION');
		}
		
		add_form_key('postform');

		$form_data = [
			'year' 			=> $this->request->variable('year', 2020),
			'annual' 		=> $this->request->variable('annual', false),
			'attend' 		=> $this->request->variable('attend', false),
			'month_string' 		=> $this->request->variable('month_string', ''),
			'country_string'	=> $this->request->variable('country_string', ''),
            'category_string'		=> $this->request->variable('category_string', ''),			
           	'city' 			=> utf8_normalize_nfc($this->request->variable('city', '',True)),
       		'full_address' 		=> utf8_normalize_nfc($this->request->variable('full_address', '',true)),
       		'key_words' 		=> $this->request->variable('key_words', ''),
			'day'			=> $this->request->variable('day', 0),
			'hour'		 	=> $this->request->variable('hour', 0),
			'minutes' 		=> $this->request->variable('minutes', 0),
			'hour_end'		 	=> $this->request->variable('hour_end', 0),
			'minutes_end' 		=> $this->request->variable('minutes_end', 0),			
			'title' 	=> utf8_normalize_nfc($this->request->variable('title', '', true)),
			'information' 	=> utf8_normalize_nfc($this->request->variable('information', '', true)),
            'organizer' 		=> utf8_normalize_nfc($this->request->variable('organizer', '',true)),
		];
		
                
		$month = date("m", strtotime($form_data['month_string']));
		$month_string = strtoupper($form_data['month_string']);
		$country_id = 1;
		$category = 1;
                
		
		$year = $this->date_time->date_key($form_data['year'], $month, $form_data['day'], "Y");

		$day_string = strtoupper($this->date_time->date_key($year, $month, $form_data['day'], "l"));

		if ($action == 'edit')
		{
			$event_data = $this->posting->get_event($event_id);
			if (empty($event_data))
			{
				throw new \phpbb\exception\http_exception(404, 'EVENT_NOT_FOUND');
			}			
			if (!$this->posting->u_event_action('u_delete_calendar_event', $event_data['user_id']))
			{
				throw new \phpbb\exception\http_exception(403, 'NO_AUTH_AUTH_EVENT_ACTION');
			}
			//temp
			$sql = 'SELECT *
				FROM ' . $this->table_events_attending  . '
				WHERE event_id = ' . (int) $event_id . '
					AND user_id = ' . (int) $this->user->data['user_id'];
			$result = $this->db->sql_query($sql);
			$attendee = $this->db->sql_fetchrow($result);
			$this->db->sql_freeresult($result);			
		}
		
		$error = [];
		if ($this->request->is_set_post('submit'))
		{		
                         
			$error = $this->posting->validate_form($error, $form_data, $month);

			$time_stamp = $this->date_time->event_timestamp($year, $month, $form_data['day'], $form_data['hour'], $form_data['minutes']);
			$time_stamp_end = $this->date_time->event_timestamp($year, $month, $form_data['day'], $form_data['hour_end'], $form_data['minutes_end']);


			$uid = $bitfield = $options = '';
			$topic_message = $form_data['information'];

			if (empty($error))
			{
				generate_text_for_storage($form_data['information'], $uid, $bitfield, $options, true, true, true, true);

				$sql_ary = [
					'user_id'		=> (int) $this->user->data['user_id'],
					'time_stamp' 		=> (int) $time_stamp,
					'time_stamp_end' 		=> (int) $time_stamp_end,
					'time_zone'		=> (string) $this->user->data['user_timezone'],
					'hour'			=> (int) $form_data['hour'],
					'minute'		=> (int) $form_data['minutes'],//s
					'hour_end'			=> (int) $form_data['hour_end'],
					'minute_end'		=> (int) $form_data['minutes_end'],//s					
					'day'         		=> (int) $form_data['day'],
					'day_string'  		=> (string) $day_string,
					'month'			=> (int) $month,
					'month_string'		=> (string) $month_string,
					'year'			=> (int) $year,
					'duration'		=> (int) 0,
					'annual'		=> (bool) $form_data['annual'],
					'title'			=> (string) $form_data['title'],
					'information'		=> (string) $form_data['information'],
					'bbcode_uid'		=> (string) $uid,
					'bbcode_bitfield'	=> (string) $bitfield,
					'country_id'		=> (int) $country_id,
					'country_string'	=> (string) $form_data['country_string'],
					'category'	=> (int) $category,	
					'category_string'	=> (string) $form_data['category_string'],									
					'city'			=> (string) $form_data['city'],
					'full_address'		=> (string) $form_data['full_address'],
					'key_words'		=> (string) $form_data['key_words'],
					'organizer'		=> (string) $form_data['organizer'],
				];
					
				$this->db->sql_transaction('begin');
				
				if ($action == 'add')
				{
					$sql = 'INSERT INTO ' . $this->table_calendar_events . ' ' . $this->db->sql_build_array('INSERT', $sql_ary);
					$this->db->sql_query($sql);
					$next_id = $this->db->sql_nextid();
					
					if (!empty($form_data['attend']))
					{
						$sql_attend = [
							'event_id'        	=> (int) $next_id,
							'user_id'     		=> (int) $this->user->data['user_id'],
							'time_stamp'        => (int) $time_stamp,
							'year'				=> (int) $year,
							'annual'			=> (bool) $form_data['annual'],
							'title'				=> (string) $form_data['title'],
						];
						
						$sql = 'INSERT INTO ' . $this->table_events_attending . ' ' . $this->db->sql_build_array('INSERT', $sql_attend);
						$this->db->sql_query($sql);
					}		
				}
				else
				{
					if (!empty($event_data['annual']) && empty($form_data['annual']))
					{
						$sql = 'DELETE FROM ' . $this->table_events_attending . '
							WHERE event_id = ' . (int) $event_id . ' 
								AND year <> ' . (int) $year;
						$this->db->sql_query($sql);

						$this->notification_manager->delete_notifications('steve.calendar.notification.type.upcoming_event', [
							'item_id'			=> $event_id,
							//'item_partent_id'	=> $event_id,
						]);
					}
					
					if (empty($form_data['attend']) && !empty($attendee['user_id']))
					{
						$event_years = !empty($event_data['annual']) && empty($form_data['annual']) ? $year : $event_data['year'];
						$sql = 'DELETE FROM ' . $this->table_events_attending . '
							WHERE event_id = ' . (int) $event_id . '
							AND user_id = ' . (int) $this->user->data['user_id'] . '
								AND year = ' . (int) $event_years;
						$this->db->sql_query($sql);

						$this->notification_manager->delete_notifications('steve.calendar.notification.type.upcoming_event', [
							'item_id'			=> $event_id,
							'item_partent_id'	=> $event_data['year'],
						]);
					}
					
					$sql_arry = [
						'time_stamp' 		=> (int) $time_stamp,
						'year'			=> (int) $year,
						'annual'		=> (bool) $form_data['annual'],
						'title'			=> (string) $form_data['title'],
					];					

					$sql = 'UPDATE ' .  $this->table_events_attending  . ' 
						SET ' . $this->db->sql_build_array('UPDATE', $sql_arry) . '
						WHERE event_id = ' . (int) $event_id;
					$this->db->sql_query($sql);
					
					$sql_arry = [
						'time_stamp' 		=> (int) $time_stamp,
						'time_stamp_end' 		=> (int) $time_stamp_end,
						'year'			=> (int) $year,
						'annual'		=> (bool) $form_data['annual'],
						'title'			=> (string) $form_data['title'],
					];

					$sql = 'UPDATE ' .  $this->table_calendar_events . ' 
						SET ' . $this->db->sql_build_array('UPDATE', $sql_ary) . '
						WHERE event_id = ' . (int) $event_id;
					$this->db->sql_query($sql);
				}
				
				$route_year = !empty($year) ? $year : date("Y");
				$route = $this->helper->route('steve_calendar_day', [
					'day_string'	=> $this->date_time->date_key($route_year, $month, $form_data['day'], "D"),
					'day'		=> $form_data['day'],
					'month' 	=> $this->date_time->date_key($route_year, $month, $form_data['day'], "F"),
					'year' 		=> !empty($form_data['year']) ? $form_data['year'] : date("Y"),
				]);
				
				if (!empty($this->config['calendar_event_post_enable']) && $action == 'add')
				{
					$day_js = $this->date_time->date_key($route_year, $month, $form_data['day'], "jS");
					$this->posting->add_topic($this->language->lang('EVENT_PREFIX', $form_data['title']), $this->posting->topic_message($year, $month, $month_string, $day_js, $route, $topic_message));
				}
				
				$this->db->sql_transaction('commit');

				meta_refresh(3, $route);
				throw new \phpbb\exception\http_exception(200, $action == 'add' ? 'EVENT_ADDED' : 'EVENT_EDITED', array($route));
			}
		}
		
		if ($action === 'edit' && empty($error))
		{
			$information= $event_data['information'];
			decode_message($information, $event_data['bbcode_uid']);
		}
		
		$months = new constants;//temp
		$countries = new constants;
		$categories = new constants;

		$this->template->assign_vars([
			'YEAR'	=> isset($event_data['year']) ? $event_data['year'] : (isset($form_data['year']) ? $form_data['year'] : $year),
			'DAY'   => isset($event_data['day']) ? $event_data['day'] : (isset($form_data['day']) ? $form_data['day'] : ''),
			'ANNUAL'=> !empty($event_data['annual']) ? $event_data['annual'] : (!empty($form_data['annual']) ? $form_data['annual'] : ''),
			'ATTEND'=> !empty($attendee['user_id']) ? true : (!empty($form_data['attend']) ? $form_data['attend'] : ''),
			'TITLE'	=> isset($event_data['title']) ? $event_data['title'] : (isset($form_data['title']) ? $form_data['title'] : ''),
			'ORGANIZER'	=> isset($event_data['organizer']) ? $event_data['organizer'] : (isset($form_data['organizer']) ? $form_data['organizer'] : ''),
			'CITY'	=> isset($event_data['city']) ? $event_data['city'] : (isset($form_data['city']) ? $form_data['city'] : ''),
			'FULL_ADDRESS'	=> isset($event_data['full_address']) ? $event_data['full_address'] : (isset($form_data['full_address']) ? $form_data['full_address'] : ''),
			'KEY_WORDS'	=> isset($event_data['key_words']) ? $event_data['key_words'] : (isset($form_data['key_words']) ? $form_data['key_words'] : ''),
			'INFORMATION'	=> isset($information) ? $information : (isset($form_data['information']) ? $form_data['information'] : ''),
			'S_MONTH_OPTION'=> $this->posting->select_month_options($this->language->lang('SELECT_MONTH'), $months->months_to_array(true), isset($event_data['month_string']) ? $event_data['month_string'] : (isset($form_data['month_string']) ? $form_data['month_string'] : '')),
			'S_COUNTRY_OPTION'=> $this->posting->select_country_options($this->language->lang('SELECT_COUNTRY'), $countries->countries_to_array(true), isset($event_data['country_string']) ? $event_data['country_string'] : (isset($form_data['country_string']) ? $form_data['country_string'] : '')),
			'S_CATEGORY_OPTION'=> $this->posting->select_category_options($this->language->lang('SELECT_CATEGORY'), $categories->categories_to_array(true), isset($event_data['category_string']) ? $event_data['category_string'] : (isset($form_data['category_string']) ? $form_data['category_string'] : '')),
			'S_HR_OPTIONS_S'	=> $this->posting->select_hrs_mins($this->language->lang('SELECT'), (int) 24, isset($event_data['hour']) ? date("h:i a",  strtotime("{$event_data['hour']}:00")) : $form_data['hour'], true),
			'S_MIN_OPTIONS_S'	=> $this->posting->select_hrs_mins($this->language->lang('SELECT'), (int) 60, isset($event_data['minute']) ? $event_data['minute'] : $form_data['minutes'], false),			
			'S_HR_OPTIONS_E'	=> $this->posting->select_hrs_mins($this->language->lang('SELECT'), (int) 24, isset($event_data['hour_end']) ? date("h:i a",  strtotime("{$event_data['hour_end']}:00")) : $form_data['hour_end'], true),
			'S_MIN_OPTIONS_E'	=> $this->posting->select_hrs_mins($this->language->lang('SELECT'), (int) 60, isset($event_data['minute_end']) ? $event_data['minute_end'] : $form_data['minutes_end'], false),			

		]);
		
		$this->posting->template_vars($this->helper->route('steve_calendar_add_event', ['action' => $action, 'event_id' => $event_id]), $error);

		return $this->helper->render('calendar_actions.html', $this->language->lang('ADD_EVENT'));		
	}
}
