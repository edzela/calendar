<?php
/**
 *
 * Events Calendar An extension for the phpBB 3.2.0 Forum Software package.
 * @author Steve <http://www.steven-clark.online/phpBB3-Extensions/>
 * @copyright (c) phpBB Limited <https://www.phpbb.com>
 * @license GNU General Public License, version 2 (GPL-2.0)
 * validate route
 */

namespace steve\calendar\controller;

/**
* Controller
*/
class attend_event
{
	/** @var \phpbb\auth\auth */
	protected $auth;
	
	/** @var \phpbb\config\config */
	protected $config;

	/** @var \phpbb\db\driver\driver */
	protected $db;

	/** @var \phpbb\controller\helper */
	protected $helper;

	/** @var \phpbb\language\language */
	protected $language;
	
	/** @var \phpbb\notification\manager */
	protected $notification_manager;
			
	/** @var \phpbb\request\request */
	protected $request;

	/** @var \phpbb\user */
	protected $user;

	protected $date;
	protected $calendar_events;
	protected $calendar_events_attending;
	protected $calendar;
	protected $routing;
	
	/**
	 * Constructor
	*/
	public function __construct(
		\phpbb\auth\auth $auth,
		\phpbb\config\config $config,		
		\phpbb\db\driver\driver_interface $db,
		\phpbb\controller\helper $helper,
		\phpbb\language\language $language,
		\phpbb\notification\manager $notification_manager,
		\phpbb\request\request $request,
		\phpbb\user $user,
		\steve\calendar\calendar\date_time $date,
		$calendar_events,
		$calendar_events_attending,
		\steve\calendar\calendar\calendar $calendar,
		\steve\calendar\calendar\routing $routing
		)
	{
		$this->auth = $auth;
		$this->config = $config;
		$this->db = $db;
		$this->helper = $helper;
		$this->language = $language;
		$this->notification_manager = $notification_manager;
		$this->request = $request;
		$this->user = $user;
		$this->date_time = $date;
		$this->table_calendar_events = $calendar_events;
		$this->table_events_attending = $calendar_events_attending;
		$this->calendar = $calendar;
		$this->routing = $routing;

		$this->language->add_lang('calendar', 'steve/calendar');

 		if (empty($this->config['calendar_enabled']) || empty($this->config['calendar_version']))
		{
			throw new \phpbb\exception\http_exception(404, 'CALENDAR_DISABLED');
		}
	}

	public function attend($action, $event_id, $year)
	{
		$this->action = $action;
		$this->event_id = (int) $event_id;
		$this->year = (int) $year;
		
		if (!in_array($action, ['attend', 'unattend']) || !check_link_hash($this->request->variable('hash', ''), ($action == 'attend' ? 'attend' : 'unattend')) 
			|| ($action == 'attend' ? !$this->auth->acl_get('u_attend_calendar_event') : !$this->auth->acl_get('u_unattend_calendar_event')))
		{
			throw new \phpbb\exception\http_exception(403, 'NO_AUTH_OPERATION');
		}
		
		$this->event_data = $this->get_event();
		$this->get_event_attendees($this->user->data['user_id']);

		if ($action == 'attend')
		{
			$this->add_attendee();
		}
		else
		{				
			$this->delete_attendee($this->user->data['user_id']);
		}

		$month = $this->event_data['month_string'];
		
		$this->routing->validate_year($year)
		->validate_month($month)
		->year_next_prev($year)
		->month_next_prev($month, $year);

		$month_route = $this->helper->route('steve_calendar_month', ['month' => $month, 'year' => $year]);

		$this->calendar->get_calendar($year, date("n", strtotime($month)))
		->get_month_events($month, 0, $year, $month_route,'');	

		return $this->helper->render('calendar.html', $this->language->lang('CALENDAR_MONTH', $month, $year));
		//return $this->response();
	}

	public function response()
	{
		if (!$this->request->is_ajax())
		{
			throw new \phpbb\exception\http_exception(500, 'GENERAL_ERROR');
		}
		
		$month_string = $this->date_time->date_key($this->year, $this->event_data['month'], 1, "F");
		$day_string = $this->date_time->date_key($this->year, $this->event_data['month'], $this->event_data['day'], "D");
					
		$data = [
			'MESSAGE_TITLE'	=> $this->language->lang('INFORMATION'),
			'MESSAGE_TEXT'	=> $this->language->lang($this->action == 'attend' ? 'ATTENDANCE_ADDED' : 'ATTENDANCE_REMOVED'),
			'REFRESH_DATA'	=> [
				'time'		=> 3,
				'url'		=> $this->helper->route('steve_calendar_day', [
				'day_string'=> $day_string, 
				'day' 		=> $this->event_data['day'], 
				'month' 	=> $month_string, 
				'year' 		=> $this->year])
		]];
		
		$json_response = new \phpbb\json_response;
		return $json_response->send($data);	
	}
	
	public function delete_attendee($user_id)
	{
		if (empty($this->event_id))
		{
			return false;
		}
				
		$sql = 'DELETE FROM ' . $this->table_events_attending . "
			WHERE event_id = $this->event_id
			AND user_id = " . (int) $user_id . "
				AND year = $this->year";
		$this->db->sql_query($sql);

		$this->notification_manager->delete_notifications('steve.calendar.notification.type.upcoming_event', [
			'item_id'			=> $this->event_id,
			'item_partent_id'	=> $this->year,
		]);
		
		return $this;		
	}
	
	public function add_attendee()
	{
		$sql_ary = [
			'event_id'        		=> (int) $this->event_id,
			'user_id'     			=> (int) $this->user->data['user_id'],
			'time_stamp'         	=> (int) $this->event_data['time_stamp'],
			'year'					=> (int) $this->year,
			'annual'				=> (bool) $this->event_data['annual'],
			'title'					=> (string) $this->event_data['title'],
		];
					
		$sql = 'INSERT INTO ' . $this->table_events_attending . ' ' . $this->db->sql_build_array('INSERT', $sql_ary);
		$this->db->sql_query($sql);

		return $this;
	}
			
	public function get_event()
	{
		$sql = 'SELECT * 	FROM ' . $this->table_calendar_events . ' WHERE event_id = "'.$this->event_id.'"';
		$result = $this->db->sql_query($sql);
		$event_data = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);
	
		if (empty($this->event_id) || empty($event_data))
		{
			throw new \phpbb\exception\http_exception(404, 'EVENT_NOT_FOUND');
		}
				
		return $event_data;
	}
	
	public function get_event_attendees($user_id)
	{
		if (empty($this->event_id))
		{
			return false;
		}
		
		$sql = 'SELECT *
			FROM ' . $this->table_events_attending  . "
			WHERE event_id = $this->event_id
				AND user_id = " . (int) $user_id . "
				AND year = $this->year";
		$result = $this->db->sql_query($sql);
		$attendees = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);
			
		if (($this->action == 'attend' && !empty($attendees)) || ($this->action == 'unattend' && empty($attendees)))
		{
			throw new \phpbb\exception\http_exception(404, $this->action == 'attend' ? 'ATTENDEE_FOUND' : 'NO_AUTH_OPERATION');
		}
			
		return $attendees;
	}	
}
