/* global phpbb */


(function($) {  

	'use strict';
	
	phpbb.addAjaxCallback('attend', function(res) {
		var tools = $('a[id^=attend_], a[id^=unattend_]');
		if (tools.is(':hidden')) {
			tools.show();
		}
		$(this).hide();
		phpbb.alert(res.MESSAGE_TITLE, res.MESSAGE_TEXT);
	});
	
	phpbb.addAjaxCallback('delete_event', function(res) {
		$('#event_' + res.EVENT_ID).remove();
		phpbb.alert(res.MESSAGE_TITLE, res.MESSAGE_TEXT);
	});
	
	})(jQuery);