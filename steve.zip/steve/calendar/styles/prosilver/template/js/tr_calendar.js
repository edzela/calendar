(function($) {  
	$(document).ready(function() {
		if (where === undefined || where === '') {
			where = 'all';
		}

		$(document).on('click', function(e) {
			if (e.target.id === 'darken') {
				closePopup(true);
			}	

		});

		$('div#nombre_evento').on('click', function() {
		//	$('body').css('overflow', 'hidden');
		//	$('.darkenwrapper').show();
			closePopup(false);
			$('div#mostrar_evento').show();
			//alert('url:'+evento_root);
	//		mostrar_evento($(this).attr('data-evento'));
			var fdata = new FormData();
			fdata.append('mode', 'mostrar_evento');
			fdata.append('id_evento', $(this).attr('data-evento'));

			$.ajax({
				method: 'POST',
				url: evento_root,
				data: fdata,
				contentType: false,
				processData: false,
				success: function(data) {
					$('body').css('overflow', 'hidden');
					$('.darkenwrapper').show();
					$('div#mostrar_evento').show();
					$('div#mostrar_evento').html(data);
				}
			});
	
		});

/*		closePopup = function(as) {
			$('div#mostrar_evento').hide();
			//$('div#mostrar_evento').css("display","none");
			if (as) $('#darken').parent().hide(); $('body').css('overflow', '');	
		}*/

	});


	closePopup = function(as) {
		$('div#mostrar_evento').hide();
		//$('div#mostrar_evento').css("display","none");
		if (as) $('#darken').parent().hide(); $('body').css('overflow', '');	
	}

/*	mostrar_evento = function(id_evento) {
			//alert('url:'+evento_root);			
			var fdata = new FormData();
			fdata.append('mode', 'mostrar_evento');
			fdata.append('id_evento', id_evento);
			$.ajax({
				method: 'POST',
				url: evento_root,
				data: fdata,
				contentType: false,
				processData: false,
				success: function(data) {
					$('div#mostrar_evento').show();
					$('div#mostrar_evento').html(data);
				}
			});
		}*/
	


})(jQuery);