<?php
/**
 *
 * Events Calendar An extension for the phpBB 3.2.0 Forum Software package.
 * @author Steve <http://www.steven-clark.online/phpBB3-Extensions/>
 * @copyright (c) phpBB Limited <https://www.phpbb.com>
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace steve\calendar\migrations;

class install_calendar extends \phpbb\db\migration\migration
{
	public function effectively_installed()
	{
		return isset($this->config['calendar_version']);
	}
	
	static public function depends_on()
	{
		return array('\phpbb\db\migration\data\v320\v320');
	}

	public function update_data()
	{
		return array(
			array('config.add', array('calendar_version', '0.5.0-dev')),
			array('config.add', array('calendar_enabled', true)),
			array('config.add', array('calendar_event_forum_id', 0)),
			array('config.add', array('calendar_event_icon_id', 0)),
			array('config.add', array('calendar_event_post_enable', false)),
			array('config.add', array('calendar_event_index', false)),
			array('config.add', array('calendar_event_limit', 25)),
			array('config.add', array('calendar_event_remind', 7)),
			array('config.add', array('calendar_event_month_limit', 1)),//
			
			array('config.add', array('calendar_cache_time', 1800)),
			array('config.add', array('calendar_cron_task_batch', 100)),
			array('config.add', array('calendar_cron_task_last_gc', 0)),
			array('config.add', array('calendar_cron_task_gc', 3600)),
			
			array('permission.add', array('u_add_calendar_event')),
			array('permission.add', array('u_attend_calendar_event')),
			array('permission.add', array('u_delete_calendar_event')),
			array('permission.add', array('u_edit_calendar_event')),
			array('permission.add', array('u_unattend_calendar_event')),
			array('permission.add', array('u_view_calendar')),
			array('permission.add', array('u_view_calendar_days')),
			array('permission.add', array('u_view_calendar_events')),

			array('module.add', array('acp', 'ACP_CAT_DOT_MODS', 'ACP_CALENDAR_TITLE')),
			array('module.add', array(
				'acp', 'ACP_CALENDAR_TITLE',
				array(
					'module_basename'	=> '\steve\calendar\acp\calendar_module',
					'modes'				=> array('settings'),
				),
			)),	
		);
	}
	
	public function update_schema()
	{
		return array(
			'add_tables'		=> array(
				$this->table_prefix . 'calendar_events'	=> array(
					'COLUMNS'		=> array(
						'event_id'        		=> array('UINT', NULL, 'auto_increment'),
						'user_id'     			=> array('UINT', 0),
						'time_stamp'         	=> array('TIMESTAMP', 0),
						'time_zone'				=> array('VCHAR:100', ''),
						'hour'					=> array('INT:2', 0),
						'minute'				=> array('INT:2', 0),
						'day'         			=> array('INT:2', 0),
						'day_string'  			=> array('VCHAR:9', ''),
						'month'					=> array('INT:2', 0),
						'month_string'			=> array('VCHAR:9', ''),
						'year'					=> array('INT:4', 0),
						'duration'				=> array('INT:3', 0),
						'annual'				=> array('BOOL', 0),
						'title'					=> array('VCHAR:100', ''),
						'information'			=> array('TEXT', ''),
						'attendees'				=> array('UINT', 0), 
						'views'     			=> array('UINT', 0),
						'post_id'     			=> array('UINT', 0),
						'bbcode_uid'			=> array('VCHAR:8', ''),
						'bbcode_bitfield'		=> array('VCHAR:255', ''),
						'bbcode_options'		=> array('UINT:11', 7),
					),
						'PRIMARY_KEY'   		=> 'event_id',
				),
				
				$this->table_prefix . 'calendar_events_attending'	=> array(
					'COLUMNS'		=> array(
						'attend_id'        		=> array('UINT', NULL, 'auto_increment'),
						'event_id'        		=> array('UINT', 0),
						'user_id'     			=> array('UINT', 0),
						'time_stamp'         	=> array('TIMESTAMP', 0),
						'year'					=> array('INT:4', 0),
						'annual'				=> array('BOOL', 0),
						'title'					=> array('VCHAR:100', ''),
						'notified'				=> array('BOOL', 0),
						'attended'				=> array('BOOL', 0),
					),
						'PRIMARY_KEY'   		=> 'attend_id',
				),
			),
		);
	}

	public function revert_schema()
	{
 		return array(
			'drop_tables'		=> array(
				$this->table_prefix . 'calendar_events',
				$this->table_prefix . 'calendar_events_attending',
			),
		);
	}
}
