<?php
/**
 *
 * Events Calendar An extension for the phpBB 3.2.0 Forum Software package.
 * @author Steve <http://www.steven-clark.online/phpBB3-Extensions/>
 * @copyright (c) phpBB Limited <https://www.phpbb.com>
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine

$lang = array_merge($lang, array(
	'CALENDAR'				=> 'Eventos',
	'CALENDAR_COPY'			=> '<a href="http://www.steven-clark.online/">phpBB Events Calendar</a>',
	'NOTIFICATION_GROUP_CALENDAR_EVENTS' 	=> 'Calendario de Eventos',
	'NOTIFICATION_TYPE_UPCOMING_EVENT'		=> 'Eventos que estas atendiendo',
	'UPCOMING_EVENT'		=> '<strong>Eventos que vienen:</strong> %1s',
	'VIEWING_CALENDAR'		=> 'Viendo el Calendario',
	
	'ANNUAL'				=> 'Eventos Anuales',
	'ADD_EVENT'				=> 'Adicionar Eventos al Calendario',
	'ATTENDANCE_ADDED' 		=> 'Has sido agregado a la lista de participantes de este evento satisfactoriamente.',
	'ATTENDANCE_REMOVED'	=> 'Has sido removido de la lista de participantes en este evento satisfactoriamente.',
	'ATTEND_EVENT'			=> 'Atender Evento',
	'ATTENDING_EVENT'		=> 'Usuarios Atendiendo',
	'ATTENDEE_FOUND'		=> 'Estas atendiendo este evento',
	
	'CALENDAR_DAY'			=> 'Calendario - %1s %2d %2s %4d',	
	'CALENDAR_MONTH'		=> 'Calendario - %1s %2d',
	'CALENDAR_YEAR'			=> 'Calendario %d',
	'CALENDAR_YEAR_EMPTY'	=> 'Calendario Año no encontrado.',
	'CALENDAR_YEAR_INVALID'	=> 'Calendario Año Invalido.',


	'DELETE_EVENT'			=> 'Borrar Evento',
	'EDIT_EVENT'			=> 'Editar Evento',
	'SEARCH_EVENTS'			=> 'Buscar Eventos',
	'SEARCH'			=> 'Buscar',


	'EVENT_ACTIVE'			=> 'Evento Activo',
	'EVENT_ADDED'			=> 'Evento adicionado satisfactoriamente.<br /><a href="%s">Ver Evento</a>',
	'EVENT_BY'				=> 'Evento creado por',
	'EVENT_DAY_INVALID'		=> 'El incorrecto número de días para %1s, número de días en %2s %1d',	
	'EVENT_DAY_TIME'		=> 'Día/Hora',
	'EVENT_DELETED'			=> 'Evento Borrado Satisfactoriamente.',
	'EVENT_EDITED'			=> 'Evento editado satisfactoriamente.<br /><a href="%s">Ver Evento</a>',
	'EVENT_EXPIRED'			=> 'Eventos Finalizados',

	'EVENT_HOUR'			=> 'Hora',
	'EVENT_HOUR_START'			=> 'Hora Inicio',
	'EVENT_HOUR_END'			=> ' -  Hora Fin',	
	'EVENT_INFORMATION'		=> 'Ínformación del Evento',
	'EVENT_MINUTE'			=> 'Minuto',
	'EVENT_NOW'				=> 'Ahora',
	'EVENT_PREFIX'			=> '[EVENT] %s',
	'EVENT_TITLE_EMPTY'		=> 'Título del evento no puede ser vacio.',
	
	'EVENT_TOPIC_MESSAGE'	=> '[b]Evento Fecha:[/b] %1s %2s %3s' . "\n" . ' [url=%4s]Ver Evento en el Calendario[/url]' . "\n" . '[b] Información del Evento:[/b]' . "\n" . '%5s' ,
	//
	'EVENT_MONTH_EMPTY'		=> 'No seleccionaste un mes para el evento.',
	'EVENT_NOT_FOUND'		=> 'El Evento requerido no existe',
	'EVENT_DAY_EMPTY'		=> 'No seleccionaste el dia para el evento.',
	'EVENT_YEAR_EMPTY'		=> 'Debes de ingresar un año valido para el evento. Si selecciona un evento anual, ingrese un año del inicio del evento o empezará.',
	
	'EVENTS_FOR'			=> 'Eventos Para',
	'EVENTS_NOW'			=> 'Eventos Ahora',
	
	'INVALID_ROUTE_DAY'		=> 'Día Calendario Invalido',
	'INVALID_ROUTE_MONTH'	=> 'Mes Calendario Invalido',
	
	'NO_AUTH_CALENDAR'		=> 'No tienes permiso para ver el calendario de eventos.',
	'NO_AUTH_DELETE_EVENT'	=> 'No tienes los permisos necesarios para borrar eventos.',
	'NO_EVENTS'				=> 'Sin Eventos.',
	
	'SELECT'				=> 'Seleccionar',
	'SELECT_MONTH'			=> 'Seleccionar Mes',
	'SELECT_COUNTRY'    	=> 'Seleccionar Pais',
    'SELECT_CATEGORY'        => 'Seleccionar Categoria',		
	'TITLE'					=> 'Titulo del Evento',
	'UNATTEND_EVENT'		=> 'Evento sin Atender',
	'COUNTRY'              	  => 'Pais',
    'CATEGORY'                => 'Categoria',		
	'CITY'      	          => 'Ciudad',
	'FULL_ADDRESS'            => 'Dirección',
	'ORGANIZER'            	  => 'Organizador',
	'KEY_WORDS'               => 'Palabras claves',
	'NEXT_EVENTS'             => 'Próximos Eventos',
	'PAST_EVENTS'             => 'Eventos Pasados',
//
	'MONDAY'		=> 'Lunes',
	'TUESDAY'		=> 'Martes',
	'WEDNESDAY'		=> 'Miércoles',
	'THURSDAY'		=> 'Jueves',
	'FRIDAY'		=> 'Viernes',
	'SATURDAY'		=> 'Sabado',
	'SUNDAY'		=> 'Domingo',
	
	'MONDAY_D'		=> 'Lun',
	'TUESDAY_D'		=> 'Mar',
	'WEDNESDAY_D'	=> 'Mie',
	'THURSDAY_D'	=> 'Jue',
	'FRIDAY_D'		=> 'Vie',
	'SATURDAY_D'	=> 'Sab',
	'SUNDAY_D'		=> 'Dom',
	
	'JANUARY'		=> 'Enero',
	'FEBRUARY'		=> 'Febrero',
	'MARCH'			=> 'Marzo',
	'APRIL'			=> 'Abril',
	'MAY'			=> 'Mayo',
	'JUNE'			=> 'Junio',
	'JULY'			=> 'Julio',
	'AUGUST'		=> 'Agosto',
	'SEPTEMBER'		=> 'Septiembre',
	'OCTOBER'		=> 'Octubre',
	'NOVEMBER'		=> 'Noviembre',
	'DECEMBER'		=> 'Diciembre',

	'January'		=> 'Enero',
	'February'		=> 'Febrero',
	'March'			=> 'Marzo',
	'April'			=> 'Abril',
	'May'			=> 'Mayo',
	'June'			=> 'Junio',
	'July'			=> 'Julio',
	'August'		=> 'Agosto',
	'September'		=> 'Septiembre',
	'October'		=> 'Octubre',
	'November'		=> 'Noviembre',
	'December'		=> 'Diciembre',
	
	'JANUARY_M'		=> 'Ene',
	'FEBUARY_M'		=> 'Feb',
	'MARCH_M'		=> 'Mar',
	'APRIL_M'		=> 'Abr',
	'MAY_M'			=> 'May',
	'JUNE_M'		=> 'Jun',
	'JULY_M'		=> 'Jul',
	'AUGUST_M'		=> 'Ago',
	'SEPTEMBER_M'	=> 'Sep',
	'OCTOBER_M'		=> 'Oct',
	'NOVEMBER_M'	=> 'Nov',
	'DECEMBER_M'	=> 'Dic',

	'ARGENTINA'		=> 'Argentina',
	'BOLIVIA'		=> 'Bolivia',
	'BRAZIL'		=> 'Brasil',
	'CHILE'			=> 'Chile',
	'COLOMBIA'		=> 'Colombia',
	'ECUADOR'		=> 'Ecuador',
	'USA'			=> 'EEUU',
	'SPAIN'			=> 'España',
	'MEXICO'		=> 'Mexico',
	'PARAGUAY'		=> 'Paraguay',
	'PERU'			=> 'Peru',
	'URUGUAY'		=> 'Uruguay',
	'VENEZUELA'		=> 'Venezuela',
	'ONLINE'		=> 'Online',

	'BLOCKCHAIN'	=> 'Blockchain',  
	'CIBERSEGURIDAD'=> 'Ciberseguridad',
	'CLOUD'			=> 'Cloud Computing',
	'DATAMANAGEMENT'=> 'Data Management',
	'DATASCIENCE'	=> 'Data Science y BI',
	'DESARROLLOSOFTWARE'	=> 'Desarrollo de Software',
	'ECOMMERCE'		=> 'eCommerce',
	'INTELLIGENCE'	=> 'Inteligencia Artificial',
	'IOT'			=> 'IOT',
	'REALIDADVIRTUAL'	=> 'Realidad Virtual y Aumentada',
	'STARTUPS'			=> 'StartUps',
	'TRANSFORMACION'	=> 'Transformación Digital',
	'TISALUD'			=> 'TI en Salud',
	'OTROS'				=> 'Otros',
	'PLUPLOAD_ADD_FILES'		=> 'Add files',
	
));
