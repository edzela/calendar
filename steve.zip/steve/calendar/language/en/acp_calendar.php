<?php
/**
 *
 * Events Calendar An extension for the phpBB 3.2.0 Forum Software package.
 * @author Steve <http://www.steven-clark.online/phpBB3-Extensions/>
 * @copyright (c) phpBB Limited <https://www.phpbb.com>
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine

$lang = array_merge($lang, array(
	'ACP_CALENDAR_CACHE_TIME'					=> 'Calendar SQL Cache time',
	'ACP_CALENDAR_CACHE_TIME_ERROR'				=> 'Calendar SQL Cache time is set at a minimum of %1d seconds and maximum %2d seconds',
	'ACP_CALENDAR_CACHE_TIME_EXPLAIN'			=> 'Time in seconds to check for new events.<br />Min: 300 Seconds (5 minutes) Max: 86400 Seconds (1 Day)',
	'ACP_CALENDAR_CRON_TASK_GC'					=> 'Upcoming Event Notification Time',
	'ACP_CALENDAR_CRON_TASK_ERROR'				=> 'Upcoming Event Notification Time is set at a minimum of %1d seconds and maximum %2d seconds',
	'ACP_CALENDAR_CRON_TASK_GC_EXPLAIN'			=> 'Time in seconds to check for Upcoming events to remind Users.<br />Min: 300 Seconds (5 minutes) Max: 86400 Seconds (1 Day)',
	'ACP_CALENDAR_ENABLE'						=> 'Enable Calendar',
	'ACP_CALENDAR_EVENT_FORUM_ID'				=> 'New Event Topic Forum id',
	'ACP_CALENDAR_EVENT_FORUM_ID_EXPLAIN'		=> '',
	'ACP_CALENDAR_EVENT_ICON_ID'				=> 'New Topic Icon',
	'ACP_CALENDAR_EVENT_ICON_ID_EXPLAIN'		=> 'Topic icon to be used with Topic Events',
	'ACP_CALENDAR_EVENT_INDEX_ENABLE'			=> 'Upcoming Events on Index',
	'ACP_CALENDAR_EVENT_LIMIT'					=> 'Events per Page',
	'ACP_CALENDAR_EVENT_LIMIT_EXPLAIN'			=> '',
	'ACP_CALENDAR_EVENT_POST_ENABLE'			=> 'Enable Posting',
	'ACP_CALENDAR_EVENT_POST_ENABLE_EXPLAIN'	=> 'Post a new Topic with new events',
	'ACP_CALENDAR_EVENT_REMIND'					=> 'Upcoming Event Notifications',
	'ACP_CALENDAR_EVENT_REMIND_EXPLAIN'			=> 'Number of days to send Event reminder Notifications to event attendees<br />Min: 1, Max: 365 days',
	'ACP_CALENDAR_EVENT_REMIND_ERROR'			=> 'Upcoming Event Notifications days are set at a minimum of %1d and maximum %2d days',
	'ACP_CALENDAR_FORUM_ID_EMPTY'				=> 'The selected Forum id is empty',
	'ACP_CALENDAR_POST_SETTINGS'				=> 'Topic Settings',
	'ACP_CALENDAR_SCHEDULED_TASK_SETTINGS'		=> 'Scheduled Tasks',
	
	
	'ACP_CALENDAR_SETTINGS'				=> 'Settings',
	'ACP_CALENDAR_SETTINGS_EXPLAIN'		=> 'Explain...',
	'ACP_CALENDAR_SETTING_SAVED'		=> 'Calendar settings saved successfully.',
	'ACP_CALENDAR_TITLE'				=> 'Calendar',
	'NO_TOPIC_ICON'						=> 'No Topic Icon',
	'LAST_RUN'							=> ' ,Last Run:',
//
	'MONDAY'		=> 'Lunes',
	'TUESDAY'		=> 'Martes',
	'WEDNESDAY'		=> 'Míercoles',
	'THURSDAY'		=> 'Jueves',
	'FRIDAY'		=> 'Viernes',
	'SATURDAY'		=> 'Sabado',
	'SUNDAY'		=> 'Domingo',
	
	'MONDAY_D'		=> 'Lun',
	'TUESDAY_D'		=> 'Mar',
	'WEDNESDAY_D'	=> 'Mie',
	'THURSDAY_D'	=> 'Jue',
	'FRIDAY_D'		=> 'Vie',
	'SATURDAY_D'	=> 'Sab',
	'SUNDAY_D'		=> 'Dom',
	
	'JANUARY'		=> 'Enero',
	'FEBRUARY'		=> 'Febrero',
	'MARCH'			=> 'Marzo',
	'APRIL'			=> 'Abril',
	'MAY'			=> 'Mayo',
	'JUNE'			=> 'Junio',
	'JULY'			=> 'Julio',
	'AUGUST'		=> 'Agosto',
	'SEPTEMBER'		=> 'Septiembre',
	'OCTOBER'		=> 'Octubre',
	'NOVEMBER'		=> 'Noviembre',
	'DECEMBER'		=> 'Diciembre',
	
	'JANUARY_M'		=> 'Ene',
	'FEBUARY_M'		=> 'Feb',
	'MARCH_M'		=> 'Mar',
	'APRIL_M'		=> 'Abr',
	'MAY_M'			=> 'May',
	'JUNE_M'		=> 'Jun',
	'JULY_M'		=> 'Jul',
	'AUGUST_M'		=> 'Ago',
	'SEPTEMBER_M'	=> 'Sep',
	'OCTOBER_M'		=> 'Oct',
	'NOVEMBER_M'	=> 'Nov',
	'DECEMBER_M'	=> 'Dic',	
));
