<?php
/* 
* https://www.phpbb.com/customise/db/extension/cronstatus/faq/1746
*/

namespace steve\calendar\cron\task;

class calendar_cron_task extends \phpbb\cron\task\base
{
	protected $config;
	
	protected $events;
	
	/**
	* Constructor.
	*
	* @param \phpbb\config\config $config The config
	*/
	public function __construct(\phpbb\config\config $config, \steve\calendar\calendar\upcoming_events $events)
	{
		$this->config = $config;
		$this->events = $events;
	}

	/**
	* Runs this cron task.
	*
	* @return null
	*/
	public function run()
	{
		// Your code goes here.
		// Do the actions that are the purpose for the Cron Job that we have created.
		$this->events->get_events();
		
		// Do not forget to update the configuration variable for last run time.
		$this->config->set('calendar_cron_task_last_gc', time());
	}

	/**
	* Returns whether this cron task should run now, because enough time
	* has passed since it was last run.
	*
	* @return bool
	*/
	public function should_run()
	{
		return $this->config['calendar_cron_task_last_gc'] < time() - $this->config['calendar_cron_task_gc'];
	}
}